#include <iostream>
#include <string>
#include <thread>
#include <chrono>

using namespace std;

// Simulated battery status
struct Battery {
    int level; // Battery level percentage (0-100)
    bool isCharging; // Charging status
};

// Function to simulate checking the battery status
Battery checkBatteryStatus() {
    // For demonstration, we will return a fixed battery status
    return {50, false}; // 50% battery, not charging
}

// Function to simulate optimizing power based on battery status
void optimizePower(Battery battery) {
    if (battery.level < 20 && !battery.isCharging) {
        cout << "Battery low! Activating battery saver mode..." << endl;
        // Simulate reducing screen brightness
        cout << "Reducing screen brightness." << endl;
        // Simulate closing background applications
        cout << "Closing background applications." << endl;
    } else if (battery.level < 50) {
        cout << "Battery level is moderate. Reducing power usage..." << endl;
        // Simulate reducing background activity
        cout << "Limiting background services." << endl;
    } else {
        cout << "Battery level is good. Normal operation." << endl;
    }
}

int main() {
    while (true) {
        Battery battery = checkBatteryStatus();
        optimizePower(battery);

        // Wait for a while before checking again
        this_thread::sleep_for(chrono::seconds(10));
    }

    return 0;
}
