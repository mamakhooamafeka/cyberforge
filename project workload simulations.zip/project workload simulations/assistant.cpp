#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <windows.h>

using namespace std;

void showTime() {
    time_t now = time(0);
    tm* ltm = localtime(&now);
    cout << "Assistant: The current time is "
         << 1 + ltm->tm_hour << ":"
         << 1 + ltm->tm_min << ":"
         << 1 + ltm->tm_sec << endl;
}

void showDate() {
    time_t now = time(0);
    tm* ltm = localtime(&now);
    cout << "Assistant: Today's date is "
         << 1900 + ltm->tm_year << "-"
         << 1 + ltm->tm_mon << "-"
         << ltm->tm_mday << endl;
}

void tellJoke() {
    cout << "Assistant: Why don't programmers like nature?" << endl;
    Sleep(2000);
    cout << "Assistant: It has too many bugs!" << endl;
}

void readFile() {
    string filename;
    cout << "Assistant: Enter file name to read (e.g., notes.txt): ";
    getline(cin, filename);

    ifstream file(filename);
    if (!file) {
        cout << "Assistant: File not found!" << endl;
        return;
    }

    cout << "\n--- File Contents ---" << endl;
    string line;
    while (getline(file, line)) {
        cout << line << endl;
    }
    file.close();
    cout << "--- End of File ---" << endl;
}

void processCommand(const string& command) {
    if (command == "open notepad") {
        cout << "Assistant: Opening Notepad..." << endl;
        system("start notepad");
    } else if (command == "open google") {
        cout << "Assistant: Opening Google..." << endl;
        system("start https://www.google.com");
    } else if (command == "open calculator") {
        cout << "Assistant: Opening Calculator..." << endl;
        system("start calc");
    } else if (command == "what is your name") {
        cout << "Assistant: I am your upgraded C++ assistant!" << endl;
    } else if (command == "time") {
        showTime();
    } else if (command == "date") {
        showDate();
    } else if (command == "joke") {
        tellJoke();
    } else if (command == "clear") {
        system("cls");
    } else if (command == "read file") {
        readFile();
    } else if (command == "help") {
        cout << "\nAssistant: Available Commands:\n";
        cout << "  - open notepad\n";
        cout << "  - open calculator\n";
        cout << "  - open google\n";
        cout << "  - what is your name\n";
        cout << "  - time\n";
        cout << "  - date\n";
        cout << "  - joke\n";
        cout << "  - read file\n";
        cout << "  - clear\n";
        cout << "  - help\n";
        cout << "  - exit\n";
    } else if (command == "exit") {
        cout << "Assistant: Goodbye!" << endl;
        exit(0);
    } else {
        cout << "Assistant: Sorry, I don't understand that command." << endl;
    }
}

int main() {
    string command;

    cout << "Assistant: Hello! Type 'help' to see what I can do." << endl;

    while (true) {
        cout << "\nYou: ";
        getline(cin, command);

        // Convert command to lowercase for case-insensitive matching
        for (char& c : command) c = tolower(c);

        processCommand(command);
    }

    return 0;
}
