#include <iostream>
#include <string>

using namespace std;

int main() {
    int choice;

    while (true) {
        cout << "Choose security: " << endl;
        cout << "1. Password " << endl;
        cout << "2. PIN " << endl;
        cout << "3. Exit" << endl;

        cin >> choice; 

        switch (choice) {
            case 1: {
                const string storedPassword = "password123"; // Example stored password
                string inputPassword;

                while (true) {
                    cout << "Enter your password: ";
                    cin >> inputPassword;

                    if (inputPassword == storedPassword) {
                        cout << "Access granted!" << endl;
                        break; 
                    } else {
                        cout << "Incorrect password. Please try again." << endl;
                    }
                }
                break;
            }

            case 2: {
                const string storedPin = "1234"; // Example stored PIN
                string inputPin;

                while (true) {
                    cout << "Enter your PIN: ";
                    cin >> inputPin;

                    if (inputPin == storedPin) {
                        cout << "Access granted!" << endl;
                        break; 
                    } else {
                        cout << "Incorrect PIN. Please try again." << endl;
                    }
                }
                break;
            }

            case 3:
                cout << "Exiting the program." << endl;
                return 0; 

            default:
                cout << "Choose a valid security option from the menu!" << endl;
                break;
        }
    }

    return 0;
}
