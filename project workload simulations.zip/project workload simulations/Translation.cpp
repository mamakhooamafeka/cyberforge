#include <iostream>
#include <map>
#include <string>

using namespace std;

// Function to initialize translation dictionaries
void initializeDictionaries(map<string, string>& engToSesotho, map<string, string>& sesothoToEng) {
    // English to Sesotho
    engToSesotho["hello"] = "lumela";
    engToSesotho["thank you"] = "kea leboha";
    engToSesotho["goodbye"] = "fonani";
    engToSesotho["yes"] = "ee";
    engToSesotho["no"] = "che";

    // Sesotho to English
    sesothoToEng["lumela"] = "hello";
    sesothoToEng["kea leboha"] = "thank you";
    sesothoToEng["fonani"] = "goodbye";
    sesothoToEng["eh"] = "yes";
    sesothoToEng["che"] = "no";
}

// Function to translate from English to Sesotho
string translateToSesotho(const string& input, const map<string, string>& engToSesotho) {
    auto it = engToSesotho.find(input);
    if (it != engToSesotho.end()) {
        return it->second;
    }
    return "Translation not found.";
}

// Function to translate from Sesotho to English
string translateToEnglish(const string& input, const map<string, string>& sesothoToEng) {
    auto it = sesothoToEng.find(input);
    if (it != sesothoToEng.end()) {
        return it->second;
    }
    return "Translation not found.";
}

int main() {
    map<string, string> engToSesotho;
    map<string, string> sesothoToEng;

    // Initialize words
    initializeDictionaries(engToSesotho, sesothoToEng);

    string input;
    int choice;

    cout << "Choose translation:" << endl;
    cout << "1. English to Sesotho" << endl;
    cout << "2. Sesotho to English" << endl;
    cout << "3. Exit" << endl;
    cin >> choice;

    while (choice != 3) {
        cout << "Enter the word/phrase: ";
        cin.ignore(); 
        getline(cin, input); // Read full line for phrases

        if (choice == 1) {
            cout << "Translation: " << translateToSesotho(input, engToSesotho) << endl;
        } else if (choice == 2) {
            cout << "Translation: " << translateToEnglish(input, sesothoToEng) << endl;
        } else {
            cout << "Invalid choice. Please try again." << endl;
        }

        cout << "Choose translation:" << endl;
        cout << "1. English to Sesotho" << endl;
        cout << "2. Sesotho to English" << endl;
        cout << "3. Exit" << endl;
        cin >> choice;
    }

    cout << "Exiting the program." << endl;
    return 0;
}

