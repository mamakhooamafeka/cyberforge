#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

// Function to calculate the Levenshtein distance between two strings
int levenshteinDistance(const string& a, const string& b) {
    vector<vector<int>> dp(a.length() + 1, vector<int>(b.length() + 1));

    for (int i = 0; i <= a.length(); ++i) {
        for (int j = 0; j <= b.length(); ++j) {
            if (i == 0) {
                dp[i][j] = j; // if a is empty
            } else if (j == 0) {
                dp[i][j] = i; // if b is empty
            } else if (a[i - 1] == b[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1]; // no change needed
            } else {
                dp[i][j] = 1 + min({dp[i - 1][j],    // deletion
                                    dp[i][j - 1],    // insertion
                                    dp[i - 1][j - 1] // substitution
                                   });
            }
        }
    }

    return dp[a.length()][b.length()];
}

// Function to suggest the best correction based on the smallest distance
string suggestCorrection(const string& input, const vector<string>& validWords) {
    string bestSuggestion;
    int smallestDistance = INT_MAX;

    for (const string& word : validWords) {
        int distance = levenshteinDistance(input, word);
        if (distance < smallestDistance) {
            smallestDistance = distance;
            bestSuggestion = word;
        }
    }

    // Suggest only if the distance is reasonable 
    return (smallestDistance <= 2) ? bestSuggestion : "";
}

int main() {
    vector<string> validWords = {"hello", "world", "example", "test", "password", "pin", "auto", "correction"};
    string userInput;

    cout << "Enter a word: ";
    cin >> userInput;

    // Check if the input is in the valid words list
    if (find(validWords.begin(), validWords.end(), userInput) != validWords.end()) {
        cout << "Word is correct!" << endl;
    } else {
        cout << "Word is incorrect." << endl;
        string suggestion = suggestCorrection(userInput, validWords);
        if (!suggestion.empty()) {
            cout << "Did you mean: " << suggestion << "?" << endl;
        } else {
            cout << "No suggestions available." << endl;
        }
    }

    return 0;
}

